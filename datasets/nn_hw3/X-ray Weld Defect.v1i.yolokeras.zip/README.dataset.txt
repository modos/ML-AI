# X-ray Weld Defect > 2024-05-22 12:56pm
https://universe.roboflow.com/danila-wjnju/x-ray-weld-defect

Provided by a Roboflow user
License: Public Domain

